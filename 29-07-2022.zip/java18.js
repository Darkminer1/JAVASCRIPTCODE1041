

class Car {
    constructor(name, year) {
      this.name = name;
      this.year = year;
    }
}
var c=new Car("ROLLS Royce","2003");
document.write(c.name+" "+c.year);